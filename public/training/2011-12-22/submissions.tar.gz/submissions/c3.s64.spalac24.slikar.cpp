#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <fstream>
#include <sstream>
#include <set>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <stack>

//..................................................

using namespace std;

typedef unsigned long long ull;
typedef long long ll;


template <class T> int toInt (T x) {
	stringstream s;
	s << x;
	int r;
	s >> r;
	return r;
}

template <class T> string toStr (T x) {
	stringstream s;
	s << x;
	return s.str();
}

int x,y,fx,fy;
int r,c;
	
void print (vector <vector <char> > v) {
	getchar();
	cout<<endl;
	for (int i = 1; i <= r; ++i) {
		for (int j = 1; j<= c ;++j){
			cout<<v[i][j];
		}
		cout<<endl;
	}
	cout<<endl;
	
}

int hasbeen[55][55];

int main () {
	cin>>r>>c;
	vector < vector <char> > mat;
	mat.resize(r+5);
	
	for (int i = 0; i < (int)mat.size(); ++i) {
		mat[i].resize(c+5);
	}
	
	for (int i = 1; i <= r; ++i) {
		for (int j = 1; j <= c; ++j) {
			cin>>mat[i][j];
			if (mat[i][j] == 'D'){
				fx = i;
				fy = j;
			}
		}
	}
	
	int times = 0;
	
	vector <vector <vector <char> > > f;
	
	f.push_back(mat);
	
	memset(hasbeen,0,sizeof hasbeen);
	
	
	while(true){
		++times;
		int lim = f.size();
		if (!lim) {
			cout<<"KAKTUS"<<endl;
			return 0;
		}
		for (int cont = 0; cont < lim; ++cont){
			//print(f[cont]);
			mat = f[cont];
			for (int i = 1; i <= r; ++i) {
				for (int j = 1; j <= c; ++j) {
						if (mat[i][j] == 'S') {
							x = i;
							y = j;
							if (mat[i-1][j] == 'D' || mat[i+1][j] == 'D' || mat[i][j-1]=='D' || mat[i][j+1] == 'D') {
								cout<<times<<endl;
								return 0;
							}
						}
						if (mat[i][j] == '*') {
							if (mat[i-1][j] == '.' || mat[i-1][j] == 'S'){
								mat[i-1][j] = ~'*';
							}
							if (mat[i+1][j] =='.' || mat[i+1][j] == 'S'){
								mat[i+1][j] = ~'*';
							}
							if (mat[i][j+1] == '.' || mat[i][j+1] == 'S'){
								mat[i][j+1] = ~'*';
							}
							if (mat[i][j-1] == '.' || mat[i][j-1] == 'S'){
								mat[i][j-1] = ~'*';
							}
						}
				}
			}
			
			for (int i = 1; i <= r; ++i) {
				for (int j = 1; j <= c; ++j) {
					if (mat[i][j] == ~'*')
						mat[i][j] = '*';
				}
			}
			
			if (mat[x][y] != '*'){
				mat[x][y] = '.';
			}
			if (y>1)
			if (mat[x][y-1] == '.' && !hasbeen[x][y-1]) {
				hasbeen[x][y-1]=1;
				mat[x][y-1] = 'S';
				f.push_back(mat);
				mat[x][y-1] = '.';
			}
			if (y+1<=c)
			if (mat[x][y+1] == '.' && !hasbeen[x][y+1]){
				hasbeen[x][y+1] = 1;
				mat[x][y+1] = 'S';
				f.push_back(mat);
				mat[x][y+1] = '.';
			}
			if (x>1)
			if (mat[x-1][y] == '.' && !hasbeen[x-1][y]) {
				hasbeen[x-1][y] = 1;
				mat[x-1][y] = 'S';
				f.push_back(mat);
				mat[x-1][y] = '.';
			}
			if (x+1 <= r)
			if (mat[x+1][y] == '.' && !hasbeen[x+1][y]){
				hasbeen[x+1][y] = 1;
				mat[x+1][y] = 'S';
				f.push_back(mat);
			}
		}
		
		f.erase(f.begin(),f.begin()+lim);
		
	}
	
}
