// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 10005;

vector<int> g[MAXN], gt[MAXN];

bool can_finish[MAXN]; // Si puede llegar al nodo final (1)
bool visited[MAXN];
int color[MAXN];

int n;

// hallar desde cuales puedo llegar al nodo final (1)
void bfs1() {
    for (int i = 0; i < n; ++i) {
        visited[i] = false;
    }
    queue<int> q;
    visited[1] = true;
    q.push( 1 );
    while (q.size() > 0) {
        int u = q.front(); q.pop();
        for (int k = 0; k < gt[u].size(); ++k) {
            int v = gt[u][k];
            if (visited[v]) continue;
            visited[v] = true;
            q.push( v );
        }
    }
    
    for (int i = 0; i < n; ++i) can_finish[i] = visited[i];
}

// retorna true si llega a un ciclo desde el que se peude terminer
// colores: 0 blanco, 1 gris, 2 negro
bool dfs1(int u) {
    if (color[u] == 1) {
        if (can_finish[u]) return true;
        return false;
    }
    if (color[u] == 2) return false;
    assert(color[u] == 0);
    
    color[u] = 1;
    
    for (int k = 0; k < g[u].size(); ++k) {
        int v = g[u][k];
        
        if (dfs1(v)) {
            return true;
        }
    }
    
    color[u] = 2;
    return false;
}

vector< int > nodes;

const int LIM = 1000000000;

int ways[MAXN];
bool big[MAXN];

// sort topologico
void sort(int u) {
    //printf("u = %d\n", u + 1);
    if (!can_finish[u]) return; // ignorar
    if (visited[u]) return;
    visited[u] = true;
    
    //printf("can_finish[u = %d]\n", u + 1);
    
    for (int k = 0; k < g[u].size(); ++k) {
        int v = g[u][k];
        //printf("u = %d -> v = %d\n", u + 1, v + 1);
        sort(v);
    }
    nodes.push_back(u);
}

int main(){
    int m;
    scanf("%d %d", &n, &m);
    for (int i = 0; i < m; ++i) {
        int u, v;
        scanf("%d %d", &u, &v);
        u--, v--;
        g[u].push_back( v );
        gt[v].push_back( u );
    }
    bfs1();
    if (dfs1(0)){
        puts("inf");
        return 0;
    }
    
    // for (int i = 0; i < n; ++i) {
    //     for (int k = 0; k < g[i].size(); ++k) {
    //            int v = g[i][k];
    //            // printf("i = %d -> v = %d\n", i + 1, v + 1);
    //     }
    // }
    
    for (int i = 0; i < n; ++i) {
        visited[i] = false;
    }
    sort(0);
    reverse(nodes.begin(), nodes.end());
    // for (int i = 0; i < nodes.size(); ++i) {
    //         D(nodes[i]);
    //     }
    
    assert(nodes.size() > 0 and nodes[0] == 0);
    ways[0] = 1;
    for (int i = 0; i < nodes.size(); ++i) {
        int u = nodes[i];
        if (ways[u] == 0) continue;
        
        for (int k = 0; k < g[u].size(); ++k) {
            int v = g[u][k];
            
            ways[v] += ways[u];
            if (big[u]) big[v] = true;
            if (ways[v] >= LIM) {
                ways[v] = ways[v] % LIM;
                big[v] = true;
            }
        }
    }
    
    if (big[1]) {
      printf("%.9d\n", ways[1]);
    } else {
      printf("%d\n", ways[1]);
    }
    return 0;
}