#include <iostream>
#include <cstdio>

using namespace std;

int main () {
    putchar(getchar());
    char c;
    while((c = getchar()) != EOF){
        while(c != '-')
            c = getchar();
        putchar(getchar());
    }
}
