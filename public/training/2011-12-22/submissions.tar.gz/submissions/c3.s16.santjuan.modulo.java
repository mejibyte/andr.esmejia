import java.util.Scanner;
import java.util.TreeSet;


public class Modulo
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		TreeSet <Integer> numeros = new TreeSet <Integer> ();
		for(int i = 0; i < 10; i++)
			numeros.add(sc.nextInt() % 42);
		System.out.println(numeros.size());
	}

}
