#include<cstdio>
#include<iostream>
#include<vector>
#include<cstdlib>
#include<algorithm>
#include<map>

using namespace std;
int main(){
	int R1,R2,S;
	while(cin>>R1>>S){
		cout << 2*S-R1 << endl;
	}
}
