// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

int reserve[15];
bool damage[15];

int main(){
    int n, S, R; cin >> n >> S >> R;
    for (int i = 0; i < S; ++i) {
        int k; cin >> k;
        assert(k <= n);
        damage[k-1] = true;
    }
    for (int i = 0; i < R; ++i) {
        int k; cin >> k;
        assert(k <= n);
        reserve[k-1]++;
    }

    for (int i = 0; i < n; ++i) {
        if (damage[i] and reserve[i] > 0) {
            damage[i] = false;
            reserve[i]--;
        }
    }
    
    int ans = 0;
    for (int i = 0; i < n; ++i) {
        if (!damage[i]) continue;
        if (i - 1 >= 0 and reserve[i - 1] > 0) {
            reserve[i - 1]--;
        } else if (reserve[i + 1] > 0) {
            reserve[i + 1]--;
        } else {
            ans++;
        }
    }
    cout << ans << endl;
    return 0;
}