// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////
string board [105];
vector <pair <int, int> > v;

bool collinear (int i, int j, int k){
    int ax = v[i].first;
    int ay = v[i].second;
    int bx = v[j].first;
    int by = v[j].second;
    int cx = v[k].first;
    int cy = v[k].second;
    // D(ax); D(ay);
    if ((bx - ax) * (cy - ay) - (by - ay) * (cx - ax) == 0) return true;
    return false;
}

int main(){
    int n; cin >> n;
    for (int i = 0; i < n; i++){
        cin >> board[i];
    }
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; ++j) {
            if (board[i][j] != '.') v.push_back(make_pair(i,j));
        }
    }
    int sum = 0;
    int m = v.size();
    for (int i = 0; i < m; i++) {
        for (int j = i + 1; j < m; ++j) {
            for (int k = j + 1; k < m; ++k) {
                if (collinear(i,j,k)) sum++;
            }            
        }
    }
    cout << sum << endl;
    return 0;
}