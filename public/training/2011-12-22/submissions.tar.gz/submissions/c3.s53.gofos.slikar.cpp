// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 51;

int rows, cols;

char board[MAXN][MAXN];
int flood_time[MAXN][MAXN];

vector< pair<int, int> > stars;

vector< pair<int, int> > people;

bool outside(int i, int j) {
    if (i < 0 or i >= rows) return true;
    if (j < 0 or j >= cols) return true;
    return false;
}

void flood() {
    queue< pair<int, int> > q;
    
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            flood_time[i][j] = -1;
        }
    }
    
    foreach(s, stars) {
        q.push(*s);
        flood_time[s->first][s->second] = 0;
    }
    
    while (q.size() > 0) {
        int i = q.front().first, j = q.front().second; q.pop();
        //printf("flooded (%d, %d)\n", i, j);
        
        for (int di = -1; di <= +1; ++di) {
            for (int dj = -1; dj <= +1; ++dj) {
                if (di == 0 and dj == 0) continue;
                if  (di != 0 and dj != 0) continue;
                
                int ni = i + di;
                int nj = j + dj;
                //D(ni); D(nj);
                //D(outside(ni, nj));
                if (outside(ni, nj)) continue;
                if (board[ni][nj] != '.' and board[ni][nj] != 'S') continue;
                //D(board[ni][nj]);
                //D(flood_time[ni][nj]);
                if (flood_time[ni][nj] != -1) continue;
                
                flood_time[ni][nj] = flood_time[i][j] + 1;
                q.push( make_pair(ni, nj) );
            }
        }
    }
}

int find_time(int si, int sj) {
    static int d[MAXN][MAXN];
    const int oo = rows * cols * 2;
    
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            d[i][j] = oo;
        }
    }
    
    d[si][sj] = 0;
    queue< pair<int, int> > q;
    q.push( make_pair(si, sj) );
    
    while (q.size() > 0) {
          int i = q.front().first, j = q.front().second; q.pop();
          // printf("popped (%d, %d)\n", i, j);
          if (board[i][j] == 'D') return d[i][j];

          for (int di = -1; di <= +1; ++di) {
              for (int dj = -1; dj <= +1; ++dj) {
                  if (di == 0 and dj == 0) continue;
                  if  (di != 0 and dj != 0) continue;

                  int ni = i + di;
                  int nj = j + dj;
                  if (outside(ni, nj)) continue;
                  if (board[ni][nj] == 'X') continue;
                 
                  int arrive_time = d[i][j] + 1;
                  if (board[ni][nj] != 'D' and flood_time[ni][nj] <= arrive_time) continue;
                  
                  if (d[ni][nj] != oo) continue;
                  
                  d[ni][nj] = arrive_time;
                  
                  q.push( make_pair(ni, nj) );
              }
          }
      }
      return oo;
}


int main(){
    cin >> rows >> cols;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> board[i][j];
            if (board[i][j] == '*') {
                stars.push_back( make_pair(i, j) );
            }
            if (board[i][j] == 'S') {
                people.push_back( make_pair(i, j) );
            }
        }
    }
    
    flood();
    
    // For(i, 0, rows) {
    //     For(j, 0, cols) {
    //         printf("%d ", flood_time[i][j]);
    //     }
    //     puts("");
    // }
    
    int ans = 0;
    foreach(p, people) {
        ans = max(ans, find_time(p->first, p->second));
    }
    
    if (ans > rows * cols) {
        puts("KAKTUS");
    } else {
        printf("%d\n", ans);
    }
    
    return 0;
}