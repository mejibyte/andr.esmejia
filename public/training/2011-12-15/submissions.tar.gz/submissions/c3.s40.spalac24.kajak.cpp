#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <fstream>
#include <sstream>
#include <set>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <stack>
#include <utility>
#include <string>


using namespace std;

int main () {
	//freopen("kajak.in","r",stdin);
	int i = 0;
	pair <int,int> pos [10];
	int R,C;
	cin>>R;
	cin>>C;
	string s;
	int count = 0;
	while(count < R) {
		cin>>s;
		int j;
		for (j = 0; j < (int)s.size(); ++j) {
			if (s[j] >= '0' and s[j] <= '9') {
				break;
			}
		}
		if (j < C){
			int play = s[j]-'0';
			//cout<<play<<" va en la pos "<<j<<endl;
			j += 3;
			int res = (int)s.size()-j;
			pos[play].first = res; pos[play].second = play;
		 }
		++count;
	}
	sort(pos+1,pos+10);
	int has [60];
	memset(has,0,sizeof has);
	count = 0;
	int fin [10];
	for (i = 1; i <= 9; ++i) {
		int j = 1;
		for(j = 1; j <= 9; ++j){
			if (pos[j].second == i)
				break;
		}
		fin[i]=j-has[pos[j].first];
		has[pos[j].first]++;
	}
	int maxpos = 9;
	for (int i = 1; i <= maxpos; ++i) {
		bool test = false;
		for (int j = 1; j <= 9; ++j) {
			if (fin[j] == i){
				test = true;
				break;
			}
		}
		if (!test) {
			for (int j = 1; j <= 9; ++j){
				if (fin[j] > i)
					--fin[j];
			}
			--i;
			--maxpos;
		}
	}
	for (int j = 1; j <= 9; ++j)
		cout<<fin[j]<<endl;
}
