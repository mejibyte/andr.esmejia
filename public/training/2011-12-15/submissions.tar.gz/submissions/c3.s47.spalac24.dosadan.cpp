#include <iostream>
#include <cstdio>

using namespace std;

int main () {
	int t;
	cin>>t;
	int x;
	int comp = 1<<6;
	while(t--){
		scanf("%x",&x);
		if (x & comp){
			cout<<"-";
		}
		else
			cout<<".";
	}
	cout<<endl;
}
