#include <iostream>

using namespace std;

int main () {
    int r,c,zr,zc;
    cin>>r>>c>>zr>>zc;
    char mat [r][c];
    for (int i = 0; i < r; ++i)
        for (int j = 0; j < c; ++j)
        cin>>mat[i][j];
    for (int i = 0; i < r; ++i){
        string thisline;
        for (int j = 0; j < c; ++j){
            for (int k = 0; k < zc; ++k)
                thisline += mat[i][j];
        }
        for (int j = 0; j < zr; ++j)
            cout<<thisline<<endl;
    }

}
