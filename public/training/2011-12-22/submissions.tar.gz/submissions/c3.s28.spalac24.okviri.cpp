#include <iostream>

using namespace std;

int main () {
	string s;
	cin>>s;
	
	int size = s.size();
	
	char mat [5][4*size+1];
	
	int lim = 4*size+1;
	
	
	for (int i = 0; i < 5; ++i)
		for (int j = 0; j < lim; ++j)
			mat[i][j]='.';
	
	for (int i = 2; i < lim; i += 4) {
		mat[0][i] = mat[4][i] = '#';
	}
	for (int i = 1; i <  lim; i += 2){
		mat[1][i] = mat[3][i] = '#';
	}
	
	
	for (int i = 0; i <  lim; i += 2) {
		if (i%4) {
			mat[2][i] = s[i/4];
		}
		else {
			mat[2][i] = '#';
		}
	}
	
	
	for (int i = 10; i+2 < lim; i += 12) {
		mat[0][i] = mat[4][i] = '*';
		mat[1][i-1] = mat[1][i+1] = mat[3][i-1] = mat[3][i+1] = '*';
		mat[2][i-2] = mat[2][i+2] = '*';
	}
	
	
	for (int i = 0; i < 5; ++i) {
		for (int j = 0; j <  lim; ++j){
			cout<<mat[i][j];
		}
		cout<<endl;
	}
	
	
	
}
