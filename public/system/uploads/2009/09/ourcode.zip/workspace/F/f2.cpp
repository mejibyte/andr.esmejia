/*
     Este c�digo pertence a
         Factor Com�n
   Por favor tr�inganlo r�pido.
*/
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
using namespace std;

template <class T> string toStr(const T &x){
    stringstream s; s << x; return s.str();
}
template <class T> int toInt(const T &x){
    stringstream s; s << x; int r; s >> r; return r;
}

#define For(i, a, b) for(int i=(a); i<(b); ++i)
#define foreach(x, v) for (typeof (v).begin() x = (v).begin(); x != (v).end(); ++x)
#define D(x) cout << #x " = " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS){
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

#define ARCHIVO "inform"

#define popcount(x) __builtin_popcount(x)

vector<pair<int, int> > ors;


bool is_good(int mask){
}

int main(){
    freopen(ARCHIVO ".in", "r", stdin);
    int nodes, edges;
    while (cin >> nodes >> edges){
        if (nodes == 0 && edges == 0) break;
        ors.clear();
        for (int k=0; k<edges; ++k){
            int u, v;
            cin >> u >> v;
            u--;
            v = (v < 0) ? v + 1 : v - 1;
            ors.push_back(make_pair(-u, v));
        }
        int ans = 0;
        for (int mask=0; mask<(1<<nodes); ++mask){
            if (is_good(mask)){
                ans = max(ans, popcount(mask));
            }
        }
        printf("%d\n", ans);
    } 
    return 0;
}
