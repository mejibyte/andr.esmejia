/*
 * @EXPECTED_RESULTS@: WRONG-ANSWER
 */
#include <cstdio>

int main(void) {
   int n;
   scanf( "%d", &n );
   for (int i = 1; i < (1 << n); ++i) {
       printf("%d ", i);
   }
   puts("");
   return 0;
}
