#include <iostream>
#include <cstdio>

using namespace std;

int main () {
    char c;
    c = getchar();
    putchar(c);
    c= getchar();
    while((c) != '\n'){
        while(c != '-' and c != '\n')
            c = getchar();
        if (c != '\n')
        c = getchar();
        if (c != '\n')
        putchar(c);
    }
    putchar('\n');
}
