#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <fstream>
#include <sstream>
#include <set>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <stack>


using namespace std;

typedef unsigned long long ull;
typedef long long ll;


template <class T> int toInt (T x) {
	stringstream s;
	s << x;
	int r;
	s >> r;
	return r;
}

template <class T> string toStr (T x) {
	stringstream s;
	s << x;
	return s.str();
}



typedef pair<ll,ll> par;

vector <par> X;
vector <par> L;

string printpar (par p){
	string s;
	s += toStr(p.first);
	s += ",";
	s += toStr(p.second);
	return s;
}

int main () {
	//freopen("BAKICE.in","r",stdin);
	ll r,c;
	cin>>r>>c;
	char mat [r][c];
	for (ll i = 0; i < r; ++i){
		for (ll j = 0; j < c; ++j){
			cin>>mat[i][j];
			if (mat[i][j] == 'X')
				X.push_back(par(i,j));
			else if (mat[i][j] == 'L')
				L.push_back(par(i,j));
		}
	}
	
	ll dist [(int)X.size()][(int)L.size()];
	ll sizex = X.size();
	ll sizel = L.size();
	//CICLOS QUE ASIGNAN DISTANCIAS
	for (ll i = 0; i < sizex; ++i) {
		for (ll j = 0 ;j < sizel; ++j) {
			dist[i][j]=(X[i].first-L[j].first)*(X[i].first-L[j].first)+(X[i].second-L[j].second)*(X[i].second-L[j].second);
		}
	}
	
	ll closer [sizel+5];
	
	ll heads [sizex+5];
	
	//DETERMINA INICIALMENTE A QUE L IRIA CADA X
	for (ll i = 0; i < sizex; ++i){
		ll Min = 0;
		for (ll j = 0; j < sizel; ++j){
			if (dist[i][j] < dist[i][Min])
				Min = j;
		}
		heads[i] = Min;
	}
	
	//DETERMINA A QUE DISTANCIA ESTA EL X MAS CERCANO DE CADA L
	for (ll i = 0; i < sizel; ++i) {
		ll Min = 1LL<<40;
		for (ll j = 0; j < sizex; ++j)
			if (dist[j][i] < Min and heads[j] == i){
				Min = dist[j][i];
		}
		closer[i]=Min;
	}
	
	//DETERMI A EL HEADS FINAL
	for (ll i = 0; i < sizex; ++i){
		ll Min = 0;
		int XX = 100000;
		while(XX--){
			for (ll j = 0; j < sizel; ++j){
				if (dist[i][j] < dist[i][Min])
					Min = j;
			}
			if (dist[i][Min] == closer[Min]){
				heads[i] = Min;
				break;
			}
			dist[i][Min] = 1LL<<40;
		}
	}
	
	
	ll hascloser[sizel+5];
	memset(hascloser,0,sizeof hascloser);
	
	for (ll i = 0; i < sizex; ++i){
		for (ll j = 0; j < sizel; ++j){
			if (heads[i] == j)
				hascloser[j]++;
		}
	}
	
	ll tot = 0;
	
	/*for (int i = 0; i < sizex; ++i){
		cout<<printpar(X[i])<<" heads "<<printpar(L[heads[i]])<<endl;
	}*/
	
	for (ll i = 0; i < sizel; ++i){
		if (hascloser[i]>1)
			++tot;
	}
	cout<<tot<<endl;
}
