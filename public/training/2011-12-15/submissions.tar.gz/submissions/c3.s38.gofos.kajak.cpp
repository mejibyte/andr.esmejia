// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
#include <cctype>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////
string a [55];
int pos [10];

bool compare(int i, int j){
    return pos[i] < pos[j];
}

int main(){
    int r, c;
    cin >> r >> c;
    for (int i = 0; i < r; i++){
        cin >> a[i];
        assert(a[i].size() == c);
    }
    for (int i = 0; i < r; i++){
        for (int j = 0; j < c; j++){
            if (isdigit(a[i][j]) ) {
                // printf("i=%d, j=%d is %c\n", i, j, a[i][j]);
                int kajak = a[i][j] - '0';
                pos[kajak] = c - j - 1;
            }
        }
    }
    
    vector< pair<int, int> > v;
    for (int i = 1; i <= 9; ++i) v.push_back( make_pair(pos[i],  i) );
    sort(v.begin(), v.end());
    
    // for (int i = 0; i < v.size(); ++i) printf("%d %d\n", v[i].first, v[i].second);
    
    int place[10] = {0};
    int cur = 1;
    for (int i = 0; i < v.size(); ++i) {
        if (i - 1 >= 0 and v[i-1].first != v[i].first) cur++;
        place[v[i].second] = cur;
    }
    for (int i = 1; i <= 9; ++i) {
        printf("%d\n", place[i]);
    }
    
    return 0;
}