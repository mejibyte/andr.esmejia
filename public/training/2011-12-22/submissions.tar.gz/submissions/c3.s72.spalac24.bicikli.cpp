#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <fstream>
#include <sstream>
#include <set>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <stack>

#define MOD 1000000000

#define MAXN 10005

using namespace std;

typedef unsigned long long ull;
typedef long long ll;


template <class T> int toInt (T x) {
	stringstream s;
	s << x;
	int r;
	s >> r;
	return r;
}

int visited[MAXN];

vector <int> graph [MAXN];
int n,r;
	
template <class T> string toStr (T x) {
	stringstream s;
	s << x;
	return s.str();
}

int x,y;

ll tot;

void dfs(int node) {
	if (visited[node]){
		tot = -1;
		return;
	}
	if (tot != -1){
		visited[node] = 1;
		if (node == 2){
			++tot;
			tot %= MOD;
		}
		int lim = graph[node].size();
		for (int i = 0; i < lim; ++i) {
			dfs(graph[node][i]);
		}
		visited[node] = 0;
	}
}

int main () {
	cin>>n>>r;
	
	for (int i = 0; i < r; ++i) {
		cin>>x>>y;
		graph[x].push_back(y);
	}
	
	tot = 0;
	
	dfs(1);
	
	if (tot != -1) {
		cout<<tot%MOD<<endl;
	}
	else{
		cout<<"inf"<<endl;
	}
	
}
