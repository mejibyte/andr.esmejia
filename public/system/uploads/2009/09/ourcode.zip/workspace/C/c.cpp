/*
     Este c�digo pertence a
         Factor Com�n
   Por favor tr�inganlo r�pido.
*/
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
using namespace std;

template <class T> string toStr(const T &x){
    stringstream s; s << x; return s.str();
}
template <class T> int toInt(const T &x){
    stringstream s; s << x; int r; s >> r; return r;
}

#define For(i, a, b) for(int i=(a); i<(b); ++i)
#define foreach(x, v) for (typeof (v).begin() x = (v).begin(); x != (v).end(); ++x)
#define D(x) cout << #x " = " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS){
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

#define ARCHIVO "coalit"

bool dp[105][10005];

int main(){
    freopen(ARCHIVO ".in", "r", stdin);
    int n, which;
    while (cin >> n >> which){
        if (n == 0 && which == 0) break;
        which--;
        vector<int> p;
        int have;
        for (int i=0; i<n; ++i){
            int x, y;
            scanf("%d.%d", &x, &y);
            x = x*100 + y;
            if (i == which) have = x;
            else p.push_back(x);
        }
        if (p.size() == 0){
            printf("100.00\n");
            continue;
        }
        memset(dp, 0, sizeof dp);
        dp[0][0] = true;
        dp[0][p[0]] = true;
        for (int i=1; i<p.size(); ++i){
            for (int j=0; j<=10000; ++j){
                dp[i][j] = dp[i-1][j];
                if (j - p[i] >= 0) dp[i][j] |= dp[i-1][j-p[i]];
            }
        }
        int k = 5001 - have;
        if (k < 0) k = 0;
        if (k == 0){
            printf("100.00\n");
            continue;
        }
        while (true){
            if (dp[p.size()-1][k]){
                //printf("i can sum %d\n", k);
                printf("%.2lf\n", 1.0 * have / (1.0 * k + have) * 100.0);
                break;
            }
            k++;
        }
    }
    return 0;
}
