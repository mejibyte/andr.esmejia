#include <iostream>
#include <cmath>

using namespace std;

int main () {
	char mat[5][5];
	for (int i = 0; i < 4; ++i){
		for (int j = 0; j < 4; ++j) {
			cin>>mat[i][j];
		}
	}
	
	int tot = 0;
	int x,y;
	for (int i = 0; i < 4; ++i) {
		for (int j = 0; j < 4; ++j) {
			if (mat[i][j] != '.'){
			x = (mat[i][j]-'A')%4;
			y = (mat[i][j]-'A')/4;
			tot += abs(x-j)+abs(y-i);
			}
		}
	}
	
	cout<<tot<<endl;
	
}
