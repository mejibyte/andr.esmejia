#include <iostream>
#include <cstdio>
#include <vector>
#include <set>
#include <string>
#include <cstring>

using namespace std;

int main(){
  string name;
  cin >> name;
  for(int i=0;i<name.size();++i){
    if(isupper(name[i])) cout << name[i];
  }
  cout << endl;
  return 0;
}