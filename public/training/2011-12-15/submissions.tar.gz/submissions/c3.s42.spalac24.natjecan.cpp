#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <fstream>
#include <sstream>
#include <set>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <stack>


using namespace std;

typedef unsigned long long ull;
typedef long long ll;


template <class T> int toInt (T x) {
	stringstream s;
	s << x;
	int r;
	s >> r;
	return r;
}

template <class T> string toStr (T x) {
	stringstream s;
	s << x;
	return s.str();
}

int main () {
	int T;
	cin>>T;
	int R,S;
	cin>>R>>S;
	
	int arr [T];
	memset(arr,0,sizeof arr);
	int x;
	for (int i = 0; i < R; ++i){
		cin>>x;
		arr[x-1]=-1;
	}
	for (int i = 0; i < S; ++i){
		cin>>x;
		arr[x-1]=1;
	}
	int tot = 0;
	for (int i = 0; i < R; ++i) {
		bool test = true;
		if (arr[i] == -1) {
			test = false;
			if (i){
				if (arr[i-1] == 1){
					arr[i-1] = 0;
					test = true;
					arr[i] = 0;
				}
			}
			else if (i+1 < R){
				if (arr[i+1] == 1){
					arr[i+1] = 0;
					arr[i] = 0;
					test = true;
				}
			}
		}
		if (!test)
			++tot;
	}
	cout<<tot<<endl;
}

