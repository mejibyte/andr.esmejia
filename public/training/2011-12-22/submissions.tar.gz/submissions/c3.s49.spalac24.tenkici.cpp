#include <iostream>
#include <cstring>
#include <utility>
#include <algorithm>
using namespace std;

struct par {
	int first,second,id;
	par(){
		first = second = id = 0;
	}
};

inline bool func1 (const par &a, const par &b){
	return a.second <= b.second;
}

inline bool func2 (const par &a, const par &b){
	return a.first <= b.first;
}

int main () {
	int n;
	cin>>n;
	int h[n];
	int v[n];
	memset(h,0,sizeof h);
	memset(v,0,sizeof v);
	
	par arr [n];
	
	int x,y;
	for (int i = 0; i < n; ++i) {
		cin>>x>>y;
		arr[i].first = x-1; arr[i].second = y-1;
		h[x] = 1;
		v[y] = 1;
		arr[i].id = i+1;
	}
	
	sort(arr,arr+n,func2);
	
	for (int i = 0; i < n; ++i) {
		while(arr[i].first > i) {
			cout<<arr[i].id<<" "<<'L'<<endl;
			--arr[i].first;
		}
		
		while(arr[i].first < i){
			cout<<arr[i].id<<" "<<'R'<<endl;
			++arr[i].first;
		}
	}
	
	sort(arr,arr+n,func1);
	
	for (int i = 0; i<  n; ++i) {
		while(arr[i].second > i) {
			cout<<arr[i].id<<" "<<'D'<<endl;
			--arr[i].second;
		}
		while(arr[i].second < i) {
			cout<<arr[i].id<<" "<<'U'<<endl;
			++arr[i].second;
		}
	}
}
