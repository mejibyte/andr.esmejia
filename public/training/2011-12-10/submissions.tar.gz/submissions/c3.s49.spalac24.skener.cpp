#include <iostream>

using namespace std;

int main () {
    int r,c,zr,zc;
    cin>>r>>c>>zr>>zc;
    string mat [c];
    for (int i = 0; i < r; ++i)
        cin>>mat[i];
    for (int i = 0; i < r; ++i){
        string thisline;
        for (int j = 0; j < c; ++j){
            for (int k = 0; k < zc; ++k)
                thisline += mat[i][j];
        }
        for (int j = 0; j < zr; ++j)
            cout<<thisline<<endl;
    }

}
