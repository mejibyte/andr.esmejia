#include <iostream>
#define COND 	if (arr[i1]+arr[i2]+arr[i3]+arr[i4]+arr[i5]+arr[i6]+arr[i7] == 100)
#define PRINT cout<<arr[i1]<<endl<<arr[i2]<<endl<<arr[i3]<<endl<<arr[i4]<<endl<<arr[i5]<<endl<<arr[i6]<<endl<<arr[i7]<<endl;

using namespace std;

int main () {
	int arr [9];
	for (int i = 0; i < 9; ++i)
		cin>>arr[i];
	for (int i1 = 0; i1 < 3; ++i1) {
		for (int i2 = i1+1; i2 < 4; ++i2) {
			for (int i3 = i2+1; i3<5; ++i3) {
				for (int i4 = i3+1; i4<6; ++i4) {
					for (int i5 = i4+1; i5<7; ++i5) {
						for (int i6 = i5+1; i6<8; ++i6) {
							for (int i7 = i6+1; i7 < 9; ++i7) {
								COND {
									cout<<arr[i1]<<endl<<arr[i2]<<endl<<arr[i3]<<endl<<arr[i4]<<endl<<arr[i5]<<endl<<arr[i6]<<endl<<arr[i7]<<endl;
								}
							}
						}
					}
				}
			}
		}
	}
}
