// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 1005, mod = 10301;
int memo[MAXN][MAXN];

int side(int len, int A) {
    //printf("len = %d, A = %d\n", len, A);
    assert(A <= len);
    
    if (len == A) return 1;
    
    if (memo[len][A] != -1) return memo[len][A];
    
    int ans = 0;
    for (int take = A; 2 * take <= len; ++take) {
        //printf("len = %d and A = %d calling (%d, %d) with take = %d\n", len, A, len - take, take, take);
        ans += side(len - take, take);
        ans %= mod;
    }
    return memo[len][A] = ans;
}

int main(){
    int N, A, B;
    cin >> N >> A >> B;
    
    memset(memo, -1, sizeof memo);
    int ans = 0;
    for (int i = A; i <= N - B; ++i) {
        for (int j = i; j <= N - B; ++j) {
            ans += side(i, A) * side(N - j, B);
            ans %= mod;
        }
    }
    cout << ans << endl;
    return 0;
}