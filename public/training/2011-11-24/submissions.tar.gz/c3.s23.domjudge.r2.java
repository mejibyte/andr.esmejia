import java.util.*;
import java.io.*;

class r2 {
    public static void main(String [] args) {
        Scanner in = new Scanner(System.in);
        int r1, s;
        r1 = in.nextInt();
        s = in.nextInt();
        System.out.printf("%d\n", 2*s-r1);
    }
}

