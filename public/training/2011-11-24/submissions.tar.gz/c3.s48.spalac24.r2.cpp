#include <iostream>

using namespace std;

int main () {
	int a,b;
	cin>>a>>b;
	cout<<2*b-a<<endl;
}
