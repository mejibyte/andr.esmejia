#include <iostream>
#include <utility>
#include <cmath>
#include <vector>
#define EPS 1e-9
using namespace std;

typedef pair<int,int> par;


inline bool func (par &a, par &b, par &c) {
	   
	   return (a.first - b.first)*(a.second - c.second) == (a.first-c.first)*(a.second-b.second);
	   
}

int main () {
	vector <par> v;
	
	int n;
	cin>>n;
	
	char c;
	
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			cin>>c;
			if (c >= 'A' and c <= 'Z') {
				v.push_back(par(i+1,n-j));
			}
		}
	}
	
	int tot = 0;
	
	int lim = v.size();
	
	for (int i = 0; i < lim; ++i) {
		for (int j = i+1; j<  lim; ++j) {
			for (int k = j+1; k < lim; ++k) {
				if (func(v[i],v[j],v[k])){
					++tot;
				}
			}
		}
	}
	
	cout<<tot<<endl;
	
}
