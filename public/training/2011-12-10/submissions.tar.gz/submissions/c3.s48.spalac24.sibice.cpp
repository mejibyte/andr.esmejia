#include <iostream>
#include <cmath>

using namespace std;

int main () {
    int n,w,h;
    cin>>n>>w>>h;
    int lim = (int)sqrt(w*w+h*h);
    int a;
    while(n--) {
        cin>>a;
        if (a <= lim)
            cout<<"DA\n";
        else
            cout<<"NE\n";
    }
}
