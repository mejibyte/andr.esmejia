// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 1000005;
int planks[MAXN];
int highest[MAXN]; // highest[i] = lo más alto que puedo subir si pongo el rodillo empezando en i hacia adelante
int mustCover[MAXN];

int painted[MAXN];

int main(){
    int N, X; scanf("%d %d", &N, &X);
    for (int i = 0; i < N; ++i) scanf("%d", &planks[i]);
    
    if (X > N) {
        long long sum = 0;
        for (int i = 0; i < N; ++i) {
            sum += planks[i];
        }
        printf("%lld\n", sum);
        puts("0");
        return 0;
    }
    
    multiset<int> window;
    for (int i = 0; i < X; ++i) window.insert(planks[i]);
    for (int i = 0; i + X <= N; ++i) {
        highest[i] = *window.begin();
        
        window.erase( window.find(planks[i]) );
        if (i + X < N) window.insert( planks[i + X] );
    }
    for (int i = N - X + 1; i < N; ++i) highest[i] = 0;
    
    window.clear();

    window.insert(highest[0]);
    for (int i = 0; i < N; ++i) {
        mustCover[i] = *--window.end();
        
        if (i - X + 1 >= 0 ) window.erase(  window.find(highest[i - X + 1]) );
        if (i + 1 < N) window.insert(  highest[i + 1] );
    }
    
    // puts("planks:"); for (int i = 0; i < N; ++i) printf("%d ", planks[i]); puts("");
    // puts("highest:"); for (int i = 0; i < N; ++i) printf("%d ", highest[i]); puts("");
    // puts("mustCover:"); for (int i = 0; i < N; ++i) printf("%d ", mustCover[i]); puts("");
    
    long long uncoveredArea = 0;
    for (int i = 0; i < N; ++i) uncoveredArea += 1LL * planks[i] - mustCover[i];
    printf("%lld\n", uncoveredArea);
    
    int swoops = 0;
    for (int i = 0; i < N; ++i) {
        int j = i;
        while (j < N and mustCover[j] == mustCover[i]) j++;
        
        int len = j - i;
        
        swoops += (len + X - 1) / X;
        i = j - 1;
    }
    printf("%d\n", swoops);
    
    return 0;
}