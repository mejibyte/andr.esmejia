#!/usr/bin/env ruby

require 'scanf'

if ARGV.size < 3
  puts "Usage: #{__FILE__} <testdata.in> <program.out> <testdata.out>"
  exit 1
end

def wrong_answer(reason)
  STDOUT.puts "Wrong Answer: #{reason}"
  exit 0
end

# File extension
class File
  def read_int
    x = self.scanf("%d")
    wrong_answer("Expected an integer but got '#{self.readline.chomp rescue "EOF"}'") if x.size != 1
    x.first
  end

  def read_char
    x = self.scanf(" %c ")
    wrong_answer("Expected a char but got '#{self.readline.chomp rescue "EOF"}'") if x.size != 1
    x.first
  end
end


class Checker
  attr_accessor :in_file, :team_file, :ans_file, :tanks

  def initialize
    self.in_file = File.open(ARGV[0])
    self.team_file = File.open(ARGV[1])
    self.ans_file = File.open(ARGV[2])
    at_exit { self.close_files }
  end

  def close_files
    in_file.close
    team_file.close
    ans_file.close
  end
  
  def valid?(tank, x, y)
    @tanks.count{|b| b[0] != tank && b[1] == x && b[2] == y}.zero?
  end
  
  def left label
    tank = @tanks.select{|x| x[0] == label}.first
    wrong_answer "Invalid move. Overlaps with other tank" unless valid?(tank[0], tank[1], tank[2] - 1)
    @tanks[@tanks.index(tank)][2] -= 1
  end

  def right label
    tank = @tanks.select{|x| x[0] == label}.first
    wrong_answer "Invalid move. Overlaps with other tank" unless valid?(tank[0], tank[1], tank[2] + 1)
    @tanks[@tanks.index(tank)][2] += 1
  end

  def up label
    tank = @tanks.select{|x| x[0] == label}.first
    wrong_answer "Invalid move. Overlaps with other tank" unless valid?(tank[0], tank[1] - 1, tank[2])
    @tanks[@tanks.index(tank)][1] -= 1
  end

  def down label
    tank = @tanks.select{|x| x[0] == label}.first
    wrong_answer "Invalid move. Overlaps with other tank" unless valid?(tank[0], tank[1] + 1, tank[2])
    @tanks[@tanks.index(tank)][1] += 1
  end


  def run

    movs = team_file.read_int
    movj = ans_file.read_int

    wrong_answer "Wrong number of movements. Expected #{movj} and got #{movs}" if movs != movj

    n = in_file.read_int
    
    @tanks = []
    
    # Each tank will be represented with a 3 dim. array as follows
    # [label, row, column]
    n.times do |i|
      x = in_file.read_int
      y = in_file.read_int
      @tanks << [i+1, x, y]
    end
    
    #### TEAM OUTPUT
    movs.times do |i|
      tank = team_file.read_int
      direc = team_file.read_char
      case direc
      when 'U'
        up tank
      when 'D'
        down tank
      when 'L'
        left tank
      when 'R'
        right tank
      end
    end
    
    n.times do |i|
      wrong_answer "More than one tank on row #{i + 1}"     unless @tanks.select{|x| x[1] == i+1}.count == 1
      wrong_answer "More than one tank on column #{i + 1}"  unless @tanks.select{|x| x[2] == i+1}.count == 1
    end
    
    exit 0
  end
end


Checker.new.run
