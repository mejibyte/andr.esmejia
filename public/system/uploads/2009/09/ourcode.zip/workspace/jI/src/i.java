import java.io.*;
import java.math.BigInteger;
import java.util.*;
public class i {
   public static int n;
   public static int [][]world;
   public final static int N = 0;
   public final static int S = 1;
   public final static int W = 2;
   public final static int E = 3;
   public static int I;
   public static int J;
   public static int DIR;
      
   static void blue_table(int i,int j, int dir)
   {
	   switch(dir) {
	      case N:
	    	  I=i;
	    	  J=j-1;
	    	  DIR = W;
	    	  break;
	      case W:
	    	  I=i+1;
	    	  J=j;
	    	  DIR = S;
	    	  break;
	      case S:
	    	  I=i;
	    	  J=j+1;
	    	  DIR = E;
	    	  break;
	      case E:
	    	  I=i-1;
	    	  J=j;
	    	  DIR = N;
	    	  break;
	   }
   }
   static void red_table(int i,int j, int dir)
   {
	   switch(dir) {
	      case N:
	    	  I=i;
	    	  J=j+1;
	    	  DIR = E;
	    	  break;
	      case W:
	    	  I=i-1;
	    	  J=j;
	    	  DIR = N;
	    	  break;
	      case S:
	    	  I=i;
	    	  J=j-1;
	    	  DIR = W;
	    	  break;
	      case E:
	    	  I=i+1;
	    	  J=j;
	    	  DIR = S;
	    	  break;
	   }
   }
   static boolean dfs(int i, int j, int dir)
   {
	   if(i==0 && j==n-1) return true;
	   if(i<0||i>=n||j<0||j>=n)return false;
	   if(world[i][j] == 1)
	   {
		   world[i][j] = 0;
		   red_table(i,j,dir);
		   return dfs(I,J,DIR);
	   }
	   else
	   {
		   world[i][j] = 1;
		   blue_table(i,j,dir);
		   return dfs(I,J,DIR);
	   }
   }
   public static void main(String []args)throws FileNotFoundException
   {
      System.setIn(new FileInputStream("langton.in"));
      Scanner reader = new Scanner(System.in);
      for(n = reader.nextInt(); n>0 ; n = reader.nextInt())
      {
    	world = new int[n][n];
        BigInteger c = reader.nextBigInteger();
        int x = reader.nextInt();
        int y = reader.nextInt();
        String C ="";
        BigInteger TWO = new BigInteger("2");
        while(c.compareTo(BigInteger.ZERO) > 0)
        {
          C = c.mod(TWO).toString() + C;
          c = c.divide(TWO);
        }
        while(C.length()<n*n) C = "0" + C;
        	
        int mask = 0;
        for(int i = n-1; i>=0;--i)
        {
        	for(int j = 0; j<n; ++j)
        	{
        	   world[i][j] = C.charAt(mask)-'0';			   
		   mask++;
        	}	
        }

        if(dfs(n-y,x-1,N)== true)
        	System.out.println("Yes");
        else
        	System.out.println("Kaputt!");
      }
   }
}
