#include <iostream>
#include <cmath>
#include <vector>
#include <cstring>
#include <utility>
#include <cstdio>

using namespace std;

typedef long long ll;


typedef pair<ll,ll> par;

vector <par> X;
vector <par> L;

int main () {
	freopen("BAKICE.in","r",stdin);
	ll r,c;
	cin>>r>>c;
	char mat [r][c];
	for (ll i = 0; i < r; ++i){
		for (ll j = 0; j < c; ++j){
			cin>>mat[i][j];
			if (mat[i][j] == 'X')
				X.push_back(par(i,j));
			else if (mat[i][j] == 'L')
				L.push_back(par(i,j));
		}
	}
	
	ll dist [(int)X.size()][(int)L.size()];
	ll sizex = X.size();
	ll sizel = L.size();
	
	for (ll i = 0; i < sizex; ++i) {
		for (ll j = 0 ;j < sizel; ++j) {
			dist[i][j]=(X[i].first-L[j].first)*(X[i].first-L[j].first)+(X[i].second-L[j].second)*(X[i].second-L[j].second);
		}
	}
	
	ll closer [sizel+5];
	
	ll heads [sizex+5];
	
	for (ll i = 0; i < sizex; ++i){
		ll Min = 0;
		for (ll j = 0; j < sizel; ++j){
			if (dist[i][j] < dist[i][Min])
				Min = j;
		}
		heads[i] = Min;
	}
	
	for (ll i = 0; i < sizel; ++i) {
		ll Min = 1LL<<40;
		for (ll j = 0; j < sizex; ++j)
			if (dist[j][i] < Min and heads[j] == i){
				Min = dist[j][i];
		}
		closer[i]=Min;
	}
	
	ll hascloser[sizel+5];
	memset(hascloser,0,sizeof hascloser);
	
	for (ll i = 0; i < sizex; ++i){
		for (ll j = 0; j < sizel; ++j){
			if (dist[i][j] == closer[j])
				hascloser[j]++;
		}
	}
	
	ll tot = 0;
	for (ll i = 0; i < sizel; ++i)
		if (hascloser[i]>1)
			++tot;
	cout<<tot<<endl;
}
