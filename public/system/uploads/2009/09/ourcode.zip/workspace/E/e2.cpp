/*
     Este c�digo pertence a
         Factor Com�n
   Por favor tr�inganlo r�pido.
*/
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
using namespace std;

template <class T> string toStr(const T &x){
    stringstream s; s << x; return s.str();
}
template <class T> int toInt(const T &x){
    stringstream s; s << x; int r; s >> r; return r;
}

#define For(i, a, b) for(int i=(a); i<(b); ++i)
#define foreach(x, v) for (typeof (v).begin() x = (v).begin(); x != (v).end(); ++x)
#define D(x) cout << #x " = " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS){
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

#define ARCHIVO "lookandsay"

char buf[1024];

int main(){
    freopen(ARCHIVO ".in", "r", stdin);
    int t,d;
    string x;
    while (cin >> x >> t >> d && t) {
        for(int i=0; i<t-1; ++i) {
            string nx = "";
            int op = 0, ini=0;
            int xsize = x.size();
            while(ini<xsize && op <= (d/2)+1) {
                int count = 1;
                for(int j=ini+1; j<xsize; ++j) {
                    if(x[j]!=x[ini]) break;
                    count++;
                }
                nx += toStr(count) + x[ini];
                ini += count;
                op++;
            }
            x = nx;
        }
        cout << x[d-1] << endl;
    }
    return 0;
}
