/*
     Este c�digo pertence a
         Factor Com�n
   Por favor tr�inganlo r�pido.
*/
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <Set>
using namespace std;

template <class T> string toStr(const T &x){
    stringstream s; s << x; return s.str();
}
template <class T> int toInt(const T &x){
    stringstream s; s << x; int r; s >> r; return r;
}

#define For(i, a, b) for(int i=(a); i<(b); ++i)
#define foreach(x, v) for (typeof (v).begin() x = (v).begin(); x != (v).end(); ++x)
#define D(x) cout << #x " = " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS){
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

int Set[50], rank[50];
void make_Set(int x) { Set[x] = x, rank[x] = 0; }
void link(int x, int y){
    if (rank[x] > rank[y]) Set[y] = x;
    else { Set[x] = y; if (rank[x] == rank[y]) rank[y]++; }
}
int find_Set(int x){
    return x != Set[x] ? Set[x] = find_Set(Set[x]) : Set[x];
}
void merge(int x, int y){ link(find_Set(x), find_Set(y)); }

#define ARCHIVO "ink"

struct point
{
    int x,y;
    point(){}
    point(int X, int Y):x(X),y(Y){}
};

bool point_in_box(double x, double y, double x0, double y0, double x1, double y1){
    return min(x0, x1) <= x && x <= max(x0, x1) &&
      min(y0, y1) <= y && y <= max(y0, y1);
}
bool segment_segment_intersection(double x0, double y0, double x1, double y1,
                                  double x2, double y2, double x3, double y3){
    double t0 = (y3-y2)*(x0-x2)-(x3-x2)*(y0-y2);
    double t1 = (x1-x0)*(y2-y0)-(y1-y0)*(x2-x0);
    double det = (y1-y0)*(x3-x2)-(y3-y2)*(x1-x0);
    if (fabs(det) < EPS){
        if (fabs(t0) < EPS || fabs(t1) < EPS){
            return (point_in_box(x0, y0,   x2, y2, x3, y3) ||
                    point_in_box(x1, y1,   x2, y2, x3, y3) ||
                    point_in_box(x2, y2,   x0, y0, x1, y1) ||
                    point_in_box(x3, y3,   x0, y0, x1, y1));
        }else{
            return false;
        }
    }else{
        t0 /= det;
        t1 /= det;
    }
    if (0.0 <= t0 && t0 <= 1.0 && 0.0 <= t1 && t1 <= 0.0){
        return true;
    }
    return false;
}

bool poly_intersect(const vector<point> &x, const vector<point> &y){
    for (int i=0; i<x.size(); ++i){
        for (int j=0; j<y.size(); ++j){
            double x0 = x[i].x,
                   y0 = x[i].y,
                   x1 = x[(i+1)%x.size()].x,
                   y1 = x[(i+1)%x.size()].y,
                   
                   x2 = y[j].x,
                   y2 = y[j].y,
                   x3 = y[(j+1)%y.size()].x,
                   y3 = y[(j+1)%y.size()].y;
                   if (segment_segment_intersection(x0, y0, x1, y1, x2, y2, x3, y3)){
                         //printf("segment (%.2lf, %.2lf)(%.2lf %.2lf) intersects (%.2lf, %.2lf)(%.2lf %.2lf)\n", x0, y0, x1, y1, x2, y2, x3, y3);
                         return true;
                    }
        }
    }
    return false;
}

double polarAngle(point p){
    if (fabs(p.x) <= EPS && fabs(p.y) <= EPS) return -1.0;
    if (fabs(p.x) <= EPS) return (p.y > EPS ? 1.0 : 3.0) * acos(0);
    double theta = atan(1.0 * p.y / p.x);
    if (p.x > EPS) return (p.y >= -EPS ? theta : (4*acos(0) + theta));
    return (2*acos(0) + theta);
}

bool pointInPoly(point p, const vector<point> &poly){
    int n = poly.size();
    double ang = 0.0;
    for (int i = n-1, j=0; j<n; i = j++){
        point v(poly[i].x - p.x, poly[i].y - p.y);
        point w(poly[j].x - p.x, poly[j].y - p.y);
        double va = polarAngle(v);
        double wa = polarAngle(w);
        double xx = wa - va;
        if (va < -0.5 || wa < -0.5 || fabs(fabs(xx)-2*acos(0)) < EPS){
            return true;
        }
        if (xx < -2 * acos(0)) ang += xx + 4*acos(0);
        else if (xx > 2*acos(0)) ang += xx - 4*acos(0);
        else ang += xx;
    }
    return (ang * ang > 1.0);
}

bool point_inside_other(const vector<point> &a, const vector<point> &b){
    for (int i=0; i<a.size(); ++i){
        if (pointInPoly(a[i], b)){
             //printf("point %d %d is inside b\n", a[i].x, a[i].y);
             return true;
        }
    }
    for (int i=0; i<b.size(); ++i){
        if (pointInPoly(b[i], a)){
             //printf("point %d %d is inside a\n", b[i].x, b[i].y);            
             return true;
        }
    }    
    return false;
}

int main(){
    freopen(ARCHIVO ".in", "r", stdin);
    int n;
    while (cin >> n && n){
        vector < vector<point> > polys;
        string s;
        getline(cin, s);
        for (int i=0; i<n; ++i){
            getline(cin, s);
            stringstream sin(s);
            vector<point> p;
            int x, y;
            while (sin >> x >> y){
                p.push_back(point(x, y));
                //printf("%d %d\n", x, y);
            }
            //printf("\n");
            polys.push_back(p);
        }
        for (int i=0; i<n; ++i){
            make_Set(i);
        }
        for (int i=0; i<n; ++i){
            for (int j=i+1; j<n; ++j){
                if (poly_intersect(polys[i], polys[j]) || point_inside_other(polys[i], polys[j])){                 
                    //printf("intersect (%d, %d)\n", i, j);
                    merge(i, j);
                }
            }
        }
        set<int> ans;
        for (int i=0; i<n; ++i) ans.insert(find_Set(i));
        printf("%d\n", ans.size());
    }
    return 0;
}
