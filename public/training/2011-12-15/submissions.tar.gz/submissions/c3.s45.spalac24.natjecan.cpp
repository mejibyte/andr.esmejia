#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <fstream>
#include <sstream>
#include <set>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <stack>


using namespace std;

typedef unsigned long long ull;
typedef long long ll;


template <class T> int toInt (T x) {
	stringstream s;
	s << x;
	int r;
	s >> r;
	return r;
}

template <class T> string toStr (T x) {
	stringstream s;
	s << x;
	return s.str();
}

int main () {
	int N;
	cin>>N;
	int R,S;
	cin>>S>>R;
	
	int arr [N+5];
	memset(arr,0,sizeof arr);
	int x;
	for (int i = 0; i < S; ++i){
		cin>>x;
		arr[x]=-1;
	}
	for (int i = 0; i < R; ++i){
		cin>>x;
		if (arr[x] == -1){
			arr[x]=0;
		}
		else
			arr[x] = 1;
	}
	int tot = 0;
	for (int i = 1; i <= N; ++i) {
		bool test = true;
		if (arr[i] == -1) {
			test = false;
			if (arr[i-1] == 1){
				//cout<<"a "<<i+1<<" le presta "<<i<<endl;
				arr[i-1] = 0;
				test = true;
			}
			else if (arr[i+1] == 1){
				//cout<<"a "<<i+1<<" le presta "<<i+2<<endl;
				arr[i+1] = 0;
				test = true;
			}
		}
		if (!test){
			++tot;
			//cout<<i<<" fails\n";
		}
	}
	cout<<tot<<endl;
}

