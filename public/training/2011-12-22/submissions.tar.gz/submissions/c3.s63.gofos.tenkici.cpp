// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
const int MAXN = 505;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////


int N, sum;
set<int> rc [2][MAXN];
vector<pair<int, char> > movs;

bool busque_izquierda(int index, int caso){
    char dir [2] = {'D', 'R'};
    int q = index;
    bool found = false;
    for (int i = index - 1; i >= 0; --i) {
        if(rc[caso][i].size() > 1){
            int p = i;
            sum += (q-p);
            for(int k = q-1; k>=p; --k){
                int barco = *(rc[caso][k].begin());
                char hasd = dir[caso];
                // printf("Moviendo el barco %d en la dirección %c\n", barco, hasd);
                rc[caso][k].erase(barco);
                rc[caso][k + 1].insert(barco);
                movs.push_back(make_pair(barco, hasd));
            }
            assert(rc[caso][index].size() == 1);
            return true;
        }

    }
    return false;
}

bool busque_derecha(int index, int caso){
    char dir [2] = {'U', 'L'};
    int q = index;
    bool found = false;
    for (int i = index + 1; i < N ; ++i) {
        if(rc[caso][i].size() > 1){
            int p = i;
            sum += abs(q-p);
            for(int k = q+1; k<=p; ++k){
                int barco = *(rc[caso][k].begin());
                char hasd = dir[caso];
                // printf("Moviendo el barco %d en la dirección %c\n", barco, hasd);
                rc[caso][k].erase(barco);
                rc[caso][k - 1].insert(barco);
                movs.push_back(make_pair(barco, hasd));
            }
            assert(rc[caso][index].size() == 1);
            return true;
        }

    }
    return false;
}

int main(){
    scanf("%d", &N);
    int x, y;
    sum = 0;
    movs.resize(0);
    for(int i=0;i<N;++i){
        cin >> x >> y;
        rc[0][--x].insert(i + 1);
        rc[1][--y].insert(i + 1);
    }
    for(int caso = 0; caso < 2; ++caso){
        for (int i = 0; i < N; ++i) {
            if(rc[caso][i].size() == 0){
                if (!busque_izquierda(i, caso)){
                    busque_derecha(i, caso);
                }
            }
        }
    }
    
    cout << sum << endl;
    for(int i=0;i<movs.size();++i){
        printf("%d %c\n", movs[i].first, movs[i].second);
    }
    
    return 0;
}