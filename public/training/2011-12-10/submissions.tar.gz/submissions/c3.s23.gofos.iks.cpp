// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

vector<int> v;
vector<int> primes;

const int MAXN = 105, MAXP = 80000;

int coef[MAXN][MAXP];
int total[MAXP];

bool isPrime(int x) {
    if (x < 2) return false;
    if (x == 2) return true;
    if (x % 2 == 0) return false;
    for (int i = 3; 1LL * i * i <= x; i += 2) {
        if (x % i == 0) return false;
    }
    return true;
}

void generatePrimes(){
    primes.push_back(2);
    for (int i = 3; i <= 1000000; i += 2) {
        if (isPrime(i)) primes.push_back(i);
    }
}

int main(){
    generatePrimes();
    
    int n; cin >> n;
    for (int i = 0; i < n; ++i){
        int x; cin >> x;
        v.push_back(x);
    }
    assert(v.size() == n);
    // D(primes.size());
    
    for (int i = 0; i < n; ++i) {
        int num = v[i];
        for (int j = 0; j < primes.size() and primes[j] <= num; j++) {
            while (num % primes[j] == 0) {
                coef[i][j]++;
                num /= primes[j];
                total[j]++;
            }
            // printf("Coef[i=%d][j=%d]= %d\n", i, j, coef[i][j]);
        }
    }
    
    int score = 0, gcd = 1;
    
    assert(n > 0);
    D(primes.size());
    for (int j = 0; j < primes.size(); ++j) {
        int split = total[j];
        split /= n;
        if  (split <= 0) continue;
        // D(primes[j]);
        // D(split);
        for (int i = 0; i < split; ++i) gcd *= primes[j];
        for (int i = 0; i < n; ++i) {
            if (coef[i][j] < split) {
                score += split - coef[i][j];
            }
        }
    }
    printf("%d %d\n", gcd, score);
    
    return 0;
}