#include <iostream>
#include <cmath>
#define PI 3.14159265L

using namespace std;

int main () {
	int r;
	cin>>r;
	cout.precision(100);
	cout<<PI*r*r<<endl<<r*r*2<<".00000000"<<endl;
}
