// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXC = 10002, mod = 1000000007;
int dp[2][MAXC];
int sum[MAXC];

int main(){
    
    int N, C; cin >> N >> C;
    
    for (int c = 0; c <= C; ++c) {
        dp[0][c] = 1;
        sum[c] = 1;
    }
    
    for (int l = 1; l <= N; ++l) {
        int cur = l & 1;
        int prev = !cur;
        
        for (int c = 0; c <= C; ++c) {
            dp[cur][c] = sum[c];
            
            if (c - l >= 0) {
                dp[cur][c] -= sum[c - l];
                
                while (dp[cur][c] < 0) dp[cur][c] += mod;
                dp[cur][c] %= mod;
            }
        }
        
        for (int c = 0; c <= C; ++c) {
            sum[c] = dp[cur][c];
            if (c - 1 >= 0) sum[c] += sum[c - 1];
            
            sum[c] %= mod;
        }
    }
    
    // for (int i = 0; i <= N; ++i) {
    //     for (int j = 0; j <= C; ++j){
    //         printf("%d ", dp[i][j]);
    //     }
    //     puts("");
    // }
    
    int ans = sum[C];
    if (C > 0) {
        ans -= sum[C - 1];
        while (ans < 0) ans += mod;
        ans %= mod;
    }
    printf("%d\n", ans);
    return 0;
}