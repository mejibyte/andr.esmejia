#include <iostream>
#include <cstring>

using namespace std;

int main () {
	int i = 0;
	int pos [10];
	memset (pos, 0, sizeof pos);
	int R,C;
	cin>>R;
	cin>>C;
	char mat [R+5][C+5];
	int count = 0;
	while(count < R) {
		for (int k = 0; k < C; ++k)
			cin>>mat[count][k];
		int j;
		for (j = 0; j < (int)C; ++j) {
			if (mat[count][j]>= '0' and mat[count][j] <= '9') {
				break;
			}
		}
		int play = mat[count][j]-'0';
		j += 3;
		int res = 1;
		while(mat[count][j] != 'F' and j < C){
			++j;
			++res;
		}
		pos[play] = res;
	}
	for (i = 1; i <= 9; ++i) {
		cout<<pos[i]<<endl;
	}
}
