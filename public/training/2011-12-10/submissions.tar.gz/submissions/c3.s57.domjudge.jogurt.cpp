/*
 * @EXPECTED_RESULTS@: WRONG-ANSWER
 */
#include <cstdio>

int main(void) {
   int n;
   scanf( "%d", &n );
   for (int i = 0; i < n; ++i) {
       printf("%d ", i + 1);
   }
   puts("");
   return 0;
}
