// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
	return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 500005;

int prev[MAXN];
int next[MAXN];

void erase(int x) {
	prev[ next[x] ] = prev[x];
	next[ prev[x] ] = next[x];
}

void A(int x, int y) {
	erase(x);
	next[x] = y;
	prev[x] = prev[y];
	next[ prev[y] ] = x;    
	prev[y] = x;
}

void B(int x, int y) {
	erase(x);
	next[x] = next[y];
	prev[x] = y;
	prev[ next[y] ] = x;
	next[y] = x;
}

vector< int > LIS(const vector< int > &s) {
	const int INF = 1 << 30;
	int n = s.size();
	vector< int > M(n + 1, INF);
	vector< int > parent(n + 1, -1);
	M[0] = 0;
	int m = 0;
	int last = -1;
	for (int i = 0; i < n; ++i) {
		int d = upper_bound(M.begin(), M.begin() + n, s[i]) - M.begin();
		assert(d > 0);
		if (s[i] != M[d - 1]) {
			M[d] = s[i];
			if (d > m) {
				m = d;
				last = i;
			}
			parent.at( s[i] ) = M[d - 1];
		}
	}
	assert( last >= 0 );
    
	vector< int > ans;
    
	for (int cur = s[last]; cur > 0; cur = parent[cur]) {
		ans.push_back(cur);
	}
	assert(m == ans.size());
	reverse(ans.begin(), ans.end());
	return ans;
}

int main(){
	int n, moves; scanf("%d %d", &n, &moves);
	for (int i = 1; i <= n; ++i) {
		prev[i] = i - 1;
		next[i] = i + 1;
	}

	for (int k = 0; k < moves; ++k) {
		char type; int x, y;
		scanf(" %c %d %d ", &type, &x, &y); 
		if (type == 'A') A(x, y);
		else if (type == 'B') B(x, y);
		else assert(false);
	}

	int first = -1;
	for (int i = 1; i <= n; ++i) {
		if (prev[i] == 0) {
			assert(first == -1);
			first = i;
		}
	}
    
    // for (int i = 1; i <= n; ++i) {
    //       printf("prev[i = %d] = %d\n", i, prev[i]);
    //       printf("next[i = %d] = %d\n", i, next[i]);
    //   }
    
	vector< int > v;
	for (int cur = first; cur > 0 and cur < n + 1; cur = next[cur]) {
		v.push_back(cur);
	}
    
    // D(v.size());
	assert(v.size() == n);
	// for (int i = 0; i < v.size(); ++i) printf("%d ", v[i]); puts("");
    
	vector< int > lis = LIS(v);
    
    // For(i, 0, lis.size()) D(lis[i]);
    
	int size = n - lis.size();
	printf("%d\n", size);
    
	set< int > ok;
	ok.insert( lis.begin(), lis.end() );
    
	for (int i = 1; i <= n; ++i) {
		if (ok.count(i)) continue;
        
		set<int>::iterator where = ok.upper_bound( i );
		if (where != ok.end()) {
            // where apunta a el proximo más grande
			printf("A %d %d\n", i, *where);
		} else {
            // no hay uno más grande
			--where;
			printf("B %d %d\n", i, *where);
		}
		ok.insert(i);
	}
	return 0;
}