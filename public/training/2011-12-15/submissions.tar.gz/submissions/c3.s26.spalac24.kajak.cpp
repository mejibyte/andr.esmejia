#include <iostream>
#include <cstring>

using namespace std;

int main () {
	string s;
	int i = 0;
	int pos [10];
	memset (pos, 0, sizeof pos);
	cin>>s;
	cin>>s;
	while(cin>>s) {
		int j;
		for (j = 0; j < (int)s.size(); ++j) {
			if (s[j]>= '0' and s[j] <= '9') {
				break;
			}
		}
		int play = s[j]-'0';
		j += 3;
		int res = 1;
		while(s[j] != 'F'){
			++j;
			++res;
		}
		pos[play] = res;
	}
	for (i = 1; i <= 9; ++i) {
		cout<<pos[i]<<endl;
	}
}
