// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

typedef pair<int, int> point;

vector< point > chairs;
vector< point > people;

bool usedChair[105 * 105];
bool satDown[105 * 105];

struct Event {
    int chair, person;
    long long distance;
    
    bool operator < (const Event &t) const {
        if (distance != t.distance) return distance < t.distance;
        if (chair != t.chair) return chair < t.chair;
        return person < t.person;
    }
};

long long distance(point a, point b) {
    long long dx = a.first - b.first;
    long long dy = a.second - b.second;
    return dx * dx + dy * dy;
}

int main(){
    int R, C;
    scanf("%d %d ", &R, &C);
    for (int i = 0; i < R; ++i) {
        for (int j = 0; j < C; ++j) {
            char c; scanf("%c ", &c);
            if (c == 'L') chairs.push_back(point(i, j));
            if (c == 'X') people.push_back(point(i, j));
        }
    }
    assert(chairs.size() * people.size() <= 5001 * 5001);
    
    vector< Event > events;
    for (int i = 0; i < chairs.size(); ++i) {
        for (int j = 0; j < people.size(); ++j) {
            Event e;
            e.chair = i;
            e.person = j;
            e.distance = ::distance(chairs[i], people[j]);
            events.push_back(e);
        }
    }
    //D(people.size()); D(chairs.size());
    sort(events.begin(), events.end());
    int ans = 0;
    
    //for (int i = 0; i < events.size(); ++i)  printf("event i=%d: prson = %d, chair = %d, dist = %lld\n", i, events[i].person, events[i].chair, events[i].distance);
    
    for (int i = 0; i < events.size(); ++i) {
        if (usedChair[events[i].chair]) continue;
        
        int ppl = 0, j;
        for (j = i; j < events.size() and events[i].distance == events[j].distance and events[i].chair == events[j].chair; j++) {
            if (!satDown[events[j].person]) {
                //printf("sat down person %d in chair %d\n", events[j].person, events[j].chair);                
                ppl++;
            }
            satDown[events[j].person] = true;
        }
        assert(events[i].chair == events[j - 1].chair);
        if (ppl > 0) usedChair[events[i].chair] = true;
        
        if (ppl > 1) ans++;
        //printf("i = %d, j = %d\n", i, j);
        i = j - 1;
    }
    printf("%d\n", ans);
    
    return 0;
}