// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

char original[4][4] = {{'A', 'B','C', 'D'},{'E', 'F', 'G', 'H'},{'I', 'J', 'K', 'L'},{'M','N', 'O', '.'}};
string puzzle [5];

int main(){
    for (int i = 0; i < 4; i++){
        cin >> puzzle[i];
    }
    int ans = 0;
    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 4; ++j){
            char letter = original[i][j];
            if (letter == '.') break;
            bool found = false;
            int k, l;
            for (k = 0; k < 4 and !found; ++k) {
                for (l = 0; l < 4 and !found; ++l) {
                    if (puzzle[k][l] == letter) found = true;
                }
            }
            //D(letter); D(k); D(l);
            ans += abs(i - (k - 1)) + abs(j -(l - 1));
        }
    }
    cout << ans << endl;
    return 0;
}