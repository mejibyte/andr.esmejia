/*
     Este c�digo pertence a
         Factor Com�n
   Por favor tr�inganlo r�pido.
*/
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
using namespace std;

template <class T> string toStr(const T &x){
    stringstream s; s << x; return s.str();
}
template <class T> int toInt(const T &x){
    stringstream s; s << x; int r; s >> r; return r;
}

#define For(i, a, b) for(int i=(a); i<(b); ++i)
#define foreach(x, v) for (typeof (v).begin() x = (v).begin(); x != (v).end(); ++x)
#define D(x) cout << #x " = " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS){
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

#define ARCHIVO "burger"

const int oo = 1000000000;

int main(){
    freopen(ARCHIVO ".in", "r", stdin);
    int n;
    while (cin >> n){
        if (n == 0) break;
        vector<int> r, d;
        r.push_back(-oo);
        int ans = oo;
        string s;
        cin >> s;
        for (int i=0; i<n; ++i){
            char c = s[i];
            if (c == '.') continue;
            if (c == 'R') r.push_back(i);
            if (c == 'D') d.push_back(i);
            if (c == 'Z') ans = 0;
        }
        if (ans < oo){
            cout << "0" << endl;
            continue;
        }
        r.push_back(oo);
        for (int i=0, j=0; i<d.size(); ++i){
            while (r[j] < d[i]){
                ans = min(ans, abs(d[i] - r[j]));
                j++;
            }
            ans = min(ans, abs(d[i] - r[j]));
            if (ans == 1) break;
        }
        printf("%d\n", ans);
    }
    return 0;
}
