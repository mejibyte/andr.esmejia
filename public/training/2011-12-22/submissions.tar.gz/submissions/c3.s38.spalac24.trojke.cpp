#include <iostream>
#include <utility>
#include <cmath>
#include <vector>
using namespace std;

typedef pair<int,int> par;

bool func (par &a, par &b, par &c) {
	return abs(double(a.first-b.first)/double(a.second-b.second)- double(b.first-c.first)/double(b.second-c.second)) < 1e-9;
}

int main () {
	vector <par> v;
	
	int n;
	cin>>n;
	
	char c;
	
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			cin>>c;
			if (c >= 'A' and c <= 'Z') {
				v.push_back(par(i,j));
			}
		}
	}
	
	int tot = 0;
	
	int lim = v.size();
	
	for (int i = 0; i < lim; ++i) {
		for (int j = i+1; j<  lim; ++j) {
			for (int k = j+1; k < lim; ++k) {
				if (func(v[i],v[j],v[k])){
					++tot;
				}
			}
		}
	}
	
	cout<<tot<<endl;
	
}
