// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 1 << 16;
int level[MAXN];
int tree[MAXN];

// llena el intervalo [a, b)
void fill(int a, int b,  int first, int incr) {
    if (b - a == 1) {
        level[a] = first;
        return;
    }
    
    assert(b - a > 1);
    
    int m = (a + b) / 2;

    level[a] = first;
    level[m] = first + incr;

    fill(a, m, first, 2 * incr);
    fill(m, b, first + incr, 2 * incr);
}

vector<int> ans;

void dfs(int u) {
    if (tree[u] == 0) return;
    ans.push_back(tree[u]);
    dfs(2 * u);
    dfs(2 * u + 1);
}

int sum(int node) {
    if (tree[node] == 0) return 0;
    int ans = tree[node];
    ans += sum(2 * node);
    ans += sum(2 * node + 1);
    return ans;
}

int main(){
    int n; cin >> n;

    int start = 1;
    for (int i = 0; i < n; ++i) {
        fill(0, start,  start, 1);
        // printf("Nivel i=%d:\n");
        // for (int i = 0; i < start; ++i) printf("%d ", level[i]); puts("");
        
        for (int i = 0; i < start; ++i) {
            tree[start + i] = level[i];
        }
        start *= 2;
    }
    start /= 2;
    
    // printf("Los que voy a reversar:\n");
    // for (int i = start; i < 2 * start; ++i) printf("%d ", tree[i]); puts("");
    
    reverse(tree + start, tree + 2 * start);
    
    // printf("después de reversar:\n");
    // for (int i = start; i < 2 * start; ++i) printf("%d ", tree[i]); puts("");
    // 
    // for (int i = 1; i <= 3; ++i) printf("Tree[i=%d] = %d\n", i, tree[i]);
   
    dfs(1);
    assert(ans.size() == 2 * start - 1);
    for (int i = 0; i < ans.size(); ++i) {
        if (i > 0) printf(" ");
        printf("%d", ans[i]);
    }
    puts("");
    
    for (int i = 0, start = 1; i < n - 1; ++i) {
    
        for (int u = start; u < 2 * start; ++u) {
            // fprintf(stderr, "Suma de subarboles del nodo i=%d:\n", u);
            
            int s1 = sum(2 * u);
            int s2 = sum(2 * u + 1);
            // fprintf(stderr, "  left = %d, right = %d\n", s1, s2);
            
            int diff = s1 - s2;
            assert(diff == start);
        }
        
        start *= 2;
    }
    
    set<int> nums; foreach(p, ans) nums.insert(*p);
    assert(nums.size() == (1 << n) - 1);
    assert(*nums.begin() == 1);
    assert(*--nums.end() == (1 << n) - 1);
    return 0;
}