#include <iostream>
#include <cmath>
#include <cstdio>
#define PI 3.14159265

using namespace std;

int main () {
	int r;
	scanf("%d",&r);
	double R = r;
	
	printf("%.6lf\n%.6lf\n",PI*R*R,R*R*2);
}
