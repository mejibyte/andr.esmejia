/*
     Este c�digo pertence a
         Factor Com�n
   Por favor tr�inganlo r�pido.
*/
#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
using namespace std;

template <class T> string toStr(const T &x){
    stringstream s; s << x; return s.str();
}
template <class T> int toInt(const T &x){
    stringstream s; s << x; int r; s >> r; return r;
}

#define For(i, a, b) for(int i=(a); i<(b); ++i)
#define foreach(x, v) for (typeof (v).begin() x = (v).begin(); x != (v).end(); ++x)
#define D(x) cout << #x " = " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS){
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

#define ARCHIVO "inform"

const int MAXN = 25;

bool g[2*MAXN][2*MAXN];


int face(int u){
    if (u >= 0) return u;
    return -u + MAXN;
}

int main(){
    freopen(ARCHIVO ".in", "r", stdin);
    int nodes, edges;
    while (cin >> nodes >> edges){
        if (nodes == 0 && edges == 0) break;
        memset(g, 0, sizeof g);
        for (int i=0; i<MAXN; ++i) g[i][i] = true;
        for (int k=0; k<edges; ++k){
            int u, v;
            cin >> u >> v;
            g[face(u)][face(v)] = true;
            g[face(-v)][face(-u)] = true;
        }
        For(k, 0, MAXN){
            For(i, 0, MAXN){
                For(j, 0, MAXN){
                    g[i][j] |= (g[i][k] && g[k][j]);
                }
            }
        }

        int ans = 0;
        bool impossible = false;
        for (int i=1; i<=nodes; ++i){
            impossible = g[i][face(-i)] && g[face(-i)][i];
            if (impossible) break;
        }
        if (impossible){
            printf("0\n");
            break;
        }
        
        
        for (int i=1; i<=nodes; ++i){
            bool can_be_true = true;
            bool can_be_false = true;
            
            for (int j=1; j<=nodes; ++j){
                if (g[i][j] && g[i][face(-j)]) can_be_true = false;
                if (g[face(-i)][j] && g[face(-i)][face(-j)]) can_be_false = false;
            }
            ans += can_be_true;
            if (can_be_true) printf("%i can be true\n", i);
        }
        printf("%d\n", ans);
    } 
    return 0;
}
