#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

int main () {
	freopen("kajak.in","r",stdin);
	int i = 0;
	int pos [10];
	memset (pos, 0, sizeof pos);
	int R,C;
	cin>>R;
	cin>>C;
	string s;
	int count = 0;
	while(count < R) {
		cin>>s;
		int j;
		for (j = 0; j < (int)C; ++j) {
			if (s[j] >= '0' and s[j] <= '9') {
				break;
			}
		}
		if (j < C){
			int play = s[j]-'0';
			j += 3;
			int res = 1;
			while(s[j] != 'F' and j < C){
				++j;
				++res;
			}
			pos[play] = res;
		 }
		++count;
	}
	for (i = 1; i <= 9; ++i) {
		cout<<pos[i]<<endl;
	}
}
