#include <iostream>

using namespace std;

int main () {
	int k;
	cin>>k;
	int mask = 1;
	int min = 0;
	int max = 0;
	while(mask < k) {
		++max;
		if (k&mask){
			if (min == 0)
				min = max;
		}
		mask <<= 1;
		if (mask == k)
		{
			max = min-1;
			break;
		}
	}
	cout<<mask<<" "<<max-min+1<<endl;
}
