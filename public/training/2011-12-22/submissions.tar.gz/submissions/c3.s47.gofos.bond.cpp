// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

const int MAXN = 20;

double dp1[2][1 << MAXN];
double dp2[2][1 << MAXN];

double P[MAXN][MAXN];

int main(){
    int n; scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int p; scanf("%d", &p);
            P[i][j] = p * 0.01;
        }
    }
    
    dp1[1][0] = 1.0;
    for (int j = 1;  j < n; ++j) dp1[1][j] = 0.0;
    
    int all = (1 << n) - 1;
    int left = n / 2;
    int right = n - left;
    
    for (int i = 0; i < left; ++i) {
        int cur = i & 1;
        int prev = !cur;
        for (int m = 0; m <= all; ++m) {
            dp1[cur][m] = 0.0;
            if (__builtin_popcount(m) > left) continue;
            
            for (int s = m; s > 0; s = s & (s - 1)) {
                int j = __builtin_ctz(s);

                double option = P[i][j] * dp1[prev][m - (1 << j)];
                
                if (option > dp1[cur][m]) dp1[cur][m] = option;
            }
        }
    }
    
    // D("dp1");
    // for (int i = left - 1; i < left; ++i) {
    //     for (int m = 0; m <= all; ++m) {
    //         printf("%lf\n", dp1[i & 1][m]);
    //     }
    // }
    // 
    for (int i = 0; i <= all;  ++i) dp2[0][i] = dp2[1][i] = 0.0;
    dp2[!(left & 1)][0] = 1.0;
    
    for (int i = left; i < n; ++i) {
        int cur = i & 1;
        int prev = !cur;
        for (int m = 0; m <= all; ++m) {
            dp2[cur][m] = 0.0;
            if (__builtin_popcount(m) > right) continue;
            
            for (int s = m; s > 0; s = s & (s - 1)) {
                int j = __builtin_ctz(s);

                double option = P[i][j] * dp2[prev][m - (1 << j)];
                if (option > dp2[cur][m]) dp2[cur][m] = option;
            }
        }
    }
    
    // D("dp2");
    // for (int i = n - 1; i < n; ++i) {
    //     for (int m = 0; m <= all; ++m) {
    //         printf("%lf\n", dp2[i & 1][m]);
    //     }
    // }
    
    double ans = 0.0;
    for (int m = 0; m <= all; ++m) {
        double option = dp1[!(left & 1)][m] * dp2[!(n & 1)][~m & all];
        if (option > ans) ans = option;
    }
    
    printf("%.8lf\n", ans * 100.0);
    return 0;
}