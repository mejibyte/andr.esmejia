// Andrés Mejía
using namespace std;
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>

////////////// Prewritten code follows. Look down for solution. ////////////////
#define foreach(x, v) for (typeof (v).begin() x=(v).begin(); x !=(v).end(); ++x)
#define For(i, a, b) for (int i=(a); i<(b); ++i)
#define D(x) cout << #x " is " << (x) << endl

const double EPS = 1e-9;
int cmp(double x, double y = 0, double tol = EPS) {
    return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}
////////////////////////// Solution starts below. //////////////////////////////

char original[55][55];
char enlarged[550][550];

int main(){
    int rows, cols, zr, zc; cin >> rows >> cols >> zr >> zc;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> original[i][j];
        }
    }
    
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            
            for (int ii = i * zr; ii < (i + 1) * zr; ++ii) {
                for (int jj = j * zc; jj < (j + 1) * zc; ++jj) {
                    enlarged[ii][jj] = original[i][j];
                }
            }
            
        }
    }
    
    for (int i = 0; i < rows * zr; ++i) {
        for (int j = 0; j < cols * zc; ++j) {
            cout << enlarged[i][j];
        }
        cout << endl;
    }
    
    return 0;
}