//Modulo
#include<iostream>
using namespace std;
int main(){
    int mod[42]={0}, i, in;
    for(i=0; i<10; i++){
        cin>>in;
        mod[in%42]++;
    }
    in=0;
    for(i=0; i<42; i++)
        in+=(mod[i]>0)?1:0;
    cout<<in<<endl;
}
