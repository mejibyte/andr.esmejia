#include <iostream>
#include <utility>
#include <cmath>
#include <vector>
#define EPS 1e-9
using namespace std;

typedef pair<int,int> par;

bool alleq (double a, double b, double c) {
	 return abs(a-b)<EPS && abs(a-c)<EPS && abs(b-c)<EPS; 
}

bool func (par &a, par &b, par &c) {
	return alleq(double(a.first-b.first)/double(a.second-b.second),double(b.first-c.first)/double(b.second-c.second),double(a.first-c.first)/double(a.second-c.second));
}

int main () {
	vector <par> v;
	
	int n;
	cin>>n;
	
	char c;
	
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			cin>>c;
			if (c >= 'A' and c <= 'Z') {
				v.push_back(par(i,j));
			}
		}
	}
	
	int tot = 0;
	
	int lim = v.size();
	
	for (int i = 0; i < lim; ++i) {
		for (int j = i+1; j<  lim; ++j) {
			for (int k = j+1; k < lim; ++k) {
				if (func(v[i],v[j],v[k])){
					++tot;
				}
			}
		}
	}
	
	cout<<tot;
	
}
