#include <cstdio>

using namespace std;

int main(){
  int r1,s;
  scanf("%d %d",&r1,&s);
  printf("%d\n",2*s-r1);

  return 0;
}
