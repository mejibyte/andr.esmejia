#include <iostream>

using namespace std;


int main () {
    unsigned long long n;
    cin>>n;
    unsigned long long res = 2;
    while(n--){
        res += (res-1);
    }
    cout<<res*res<<endl;
}
