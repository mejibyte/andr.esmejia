#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> all;
int n;
int arr [105];

void getdiv(int x){
    //cout<<"in getdiv\n";
    int i;
    for (i = 2; i*i < x; ++i){
        if (!(x%i))
        {
            int aux = i;
            while(!(x%aux)){
                all.push_back(i);
                all.push_back(x/i);
                aux *= i;
               // cout<<i<<" es divisor de "<<x<<endl;
            }
        }
    }
    if (i*i == x){
        all.push_back(i);
        all.push_back(i);
    }
   // cout<<"exit getdiv\n";
}
int check (int x){
   // cout<<"check\n";
    int ret = 0;
    for (int i = 0; i < n; ++i)
        if (arr[i]%x)
            ++ret;
    return ret;
}

int main () {
    cin>>n;
    for (int i = 0; i < n; ++i){
        cin>>arr[i];
        getdiv(arr[i]);
    }

    sort(all.begin(),all.end());
    for (int i = all.size()-1; i >= 0; --i){
        while( all[i] ==  all[i-1])
            --i;
        if (count(all.begin(),all.end(),all[i])>=n){
            cout<<all[i]<<" "<<check(all[i])<<endl;
            return 0;}
    }
    cout<<"1 0\n";
    return 0;
}
